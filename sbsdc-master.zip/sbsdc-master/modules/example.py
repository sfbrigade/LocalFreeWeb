#!/usr/bin/python
# # # # # # # # # # # # # # # # # # # # # # 
#
# project: Smart Bus Stops Done Dirt Cheap
# title: example
# file: example.py
# description: example modulefor SBSDC
# language: python
# 
# authors: Anders Finn (anders@visiblethinking.com)
# date: 9/9/2012
# version: 1.0.0
# notes: An example of what a module needs for input and output.
#
# keywords: example
#
# # # # # # # # # # # # # # # # # # # # # #
import sys
#args = sys.argv

print "Visible Thinking is AWESOME!"